#include <iostream>
using namespace std;

    int main () {
        char nome[10];
        int letrasA = 0;
        int letrasI = 0;

        cout << "Diz o teu primeiro nome:  \n";
        cin  >> nome[10];

        cout << nome << " o teu nome tem: \n";
        cout <<  letrasA << " letras A e " << letrasI << " letras I";



    return 0;
    }
