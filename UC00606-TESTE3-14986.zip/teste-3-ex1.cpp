#include <iostream>
using namespace std;
# define N 5

int main (){

     int numeros[N], soma = 0 ;

     for (int i = 0; i < N; i++){
        cout << "Diz me 5 numeros:  \n";
        cin  >> numeros[N];
        soma += numeros[N];
     }
     cout << soma;

    return 0;
}
